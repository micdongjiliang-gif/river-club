# 河牌俱乐部 · 安卓离线扑克

目标：Android 8.0 及以上。离线单人游戏，虚拟筹码，无联网权限。

## 当前状态

- 已完成规则核心、AI、手机网页界面、Android 原生离线外壳。
- 15 项规则与 AI 测试通过，包括全部 2,598,960 种五张牌的分类和 2,000 手随机对局。
- **APK 未生成；浏览器端到端测试和 Android 编译、安装、实机生命周期测试尚未完成。** 当前执行沙箱拦截网络和套接字操作，安卓 SDK 与 Gradle 尚未下载。
- 训练为基础概念题和决策提示；不是求解器，不提供最优策略评分。后续可增加变化情境的专项训练、按位置统计和更深入的范围分析。

## 测试

```sh
node --test --test-isolation=none --test-reporter=spec tests/engine.test.mjs
node --check app/src/main/assets/app.js
```

完整浏览器检查脚本为 `tests/browser.cjs`；当前引用工作环境已安装的 Playwright 路径和 Chromium 路径。换环境时按实际安装路径修改。该检查在 393×852 竖屏下覆盖 AI 行动、弃牌结算、暂停与刷新恢复、概率工具、公平核验、历史、训练和单挑切换。

## 安卓构建

需要 JDK 17/21、Android SDK Platform 35、Build Tools 35.0.0、Gradle 8.9。

```sh
gradle :app:assembleDebug
```

输出 `app/build/outputs/apk/debug/app-debug.apk` 为开发测试包。完成浏览器与 Android 安装验证后，再生成非调试的签名 release 包。没有经过验证的 APK 不应标为可靠版本。

可使用 Android Studio 打开此目录，在 SDK Manager 安装对应 SDK 后构建。`scripts/build-android.sh` 提供从官方下载工具的构建路径；需要环境允许网络连接。

## 固定规则与公平

无限注德州扑克，起始 2,000 筹码、10/20 盲注、无前注与抽水。六人或单挑。现金桌 AI 破产后下一手补足到 2,000；人类可在手牌结束后补码。锦标赛每 20 手盲注翻倍，封顶 320/640，无奖金结构，不计算 ICM。

密码学随机数采用拒绝采样后 Fisher–Yates 洗牌。发牌前保存 `SHA-256(JSON.stringify({deck,nonce}))`，结束后公开牌序与随机盐。承诺仅检查一致性，不能独立证明软件无缺陷。

`Table.observation()` 是 AI 唯一输入接口，不包含牌堆、随机盐或其他座位底牌。AI 使用未知手牌随机抽样估算，不能视为职业级策略。

保存使用本机 WebView localStorage。每次合法行动后保存完整牌局；恢复保持原牌序。卸载、清数据会删除存档。历史保留最近 200 手，Android 文档选择器可导出 JSON。

## 发布前仍需验证

1. 运行浏览器完整检查，检查窄屏、按钮和错误反馈。
2. 编译 Android 工程，检查 Java/API 兼容与资源装载。
3. Android 上核验 JavaScript 模块、Web Worker、crypto、localStorage 可用。
4. 实测切后台、进程终止、重新打开、旋转屏幕和导出记录。
5. Android 15 的状态栏与导航栏适配；更新 WebView 时的兼容性。
6. 生成并验证 APK 签名，安装后完成多手对局。

源码不能替代安装包。本目录仅为当前可审查的开发成果。
