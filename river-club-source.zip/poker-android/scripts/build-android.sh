#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
TOOLS_DIR="${RIVER_TOOLS_DIR:-/workspace/android-tools}"
mkdir -p "$TOOLS_DIR" "$PROJECT_DIR/outputs"
if [[ ! -x "$TOOLS_DIR/sdk/cmdline-tools/latest/bin/sdkmanager" ]]; then
  curl --fail --location --connect-timeout 10 --max-time 180 --output "$TOOLS_DIR/cmdline.zip" https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
  mkdir -p "$TOOLS_DIR/sdk/cmdline-tools"
  unzip -q -o "$TOOLS_DIR/cmdline.zip" -d "$TOOLS_DIR/sdk/cmdline-tools"
  mv "$TOOLS_DIR/sdk/cmdline-tools/cmdline-tools" "$TOOLS_DIR/sdk/cmdline-tools/latest"
fi
export ANDROID_HOME="$TOOLS_DIR/sdk"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
set +o pipefail
yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses >/dev/null
set -o pipefail
"$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" 'platforms;android-35' 'build-tools;35.0.0'
if [[ ! -x "$TOOLS_DIR/gradle-8.9/bin/gradle" ]]; then
  curl --fail --location --connect-timeout 10 --max-time 180 --output "$TOOLS_DIR/gradle.zip" https://services.gradle.org/distributions/gradle-8.9-bin.zip
  unzip -q -o "$TOOLS_DIR/gradle.zip" -d "$TOOLS_DIR"
fi
cd "$PROJECT_DIR"
"$TOOLS_DIR/gradle-8.9/bin/gradle" --no-daemon :app:assembleDebug
cp app/build/outputs/apk/debug/app-debug.apk outputs/river-club-debug.apk
"$ANDROID_HOME/build-tools/35.0.0/apksigner" verify --verbose outputs/river-club-debug.apk
printf 'Built development APK: %s/outputs/river-club-debug.apk\n' "$PROJECT_DIR"
