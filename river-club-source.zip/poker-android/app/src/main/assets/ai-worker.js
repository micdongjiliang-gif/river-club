import {decide,equity} from './engine.js';
self.onmessage=({data})=>{try{self.postMessage(data.estimate?{equity:equity(data.obs,600)}:decide(data.obs,data.difficulty,data.style))}catch(e){self.postMessage({error:e.message})}};
