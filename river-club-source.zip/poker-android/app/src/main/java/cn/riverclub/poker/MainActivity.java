package cn.riverclub.poker;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.graphics.Color;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.ByteArrayInputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** Offline-only app. No Internet permission; HTTPS origin is intercepted locally. */
public final class MainActivity extends Activity {
    private static final String HOST = "app.riverclub.local";
    private static final int EXPORT = 10;
    private WebView web;
    private String pendingExport;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(9,23,30));
        getWindow().setNavigationBarColor(Color.rgb(9,23,30));
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(9,23,30));
        if(android.os.Build.VERSION.SDK_INT>=35) {
            web.setOnApplyWindowInsetsListener((view,insets)->{
                android.graphics.Insets bars=insets.getInsets(android.view.WindowInsets.Type.systemBars() | android.view.WindowInsets.Type.displayCutout());
                view.setPadding(bars.left,bars.top,bars.right,bars.bottom);
                return insets;
            });
        }
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSupportMultipleWindows(false);
        web.addJavascriptInterface(new ExportBridge(), "Android");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return !HOST.equals(r.getUrl().getHost());
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u=r.getUrl();
                if (!"https".equals(u.getScheme()) || !HOST.equals(u.getHost())) return empty();
                String path=u.getPath();
                if (path==null || path.equals("/")) path="/index.html";
                if (path.contains("..") || path.substring(1).contains("/")) return empty();
                String mime=path.endsWith(".js")?"text/javascript":path.endsWith(".css")?"text/css":path.endsWith(".html")?"text/html":"application/octet-stream";
                try { return new WebResourceResponse(mime,"UTF-8",getAssets().open(path.substring(1))); }
                catch (Exception e) { return empty(); }
            }
        });
        setContentView(web);
        web.loadUrl("https://"+HOST+"/index.html");
    }
    private WebResourceResponse empty() { return new WebResourceResponse("text/plain","UTF-8",new ByteArrayInputStream(new byte[0])); }
    private final class ExportBridge {
        @JavascriptInterface public void exportHistory(String json) {
            if(json==null || json.length()>12000000) return;
            pendingExport=json;
            runOnUiThread(() -> {
                Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE,"river-club-history.json");
                startActivityForResult(intent,EXPORT);
            });
        }
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request,result,data);
        if(request==EXPORT && result==RESULT_OK && data!=null && pendingExport!=null) {
            try(OutputStream out=getContentResolver().openOutputStream(data.getData())) {
                if(out==null) throw new Exception("No output stream");
                out.write(pendingExport.getBytes(StandardCharsets.UTF_8));
                Toast.makeText(this,"手牌记录已导出",Toast.LENGTH_SHORT).show();
            } catch(Exception e) { Toast.makeText(this,"导出失败，请重试",Toast.LENGTH_LONG).show(); }
        }
        if(request==EXPORT) pendingExport=null;
    }
    @Override protected void onPause() {
        web.evaluateJavascript("window.appPause&&window.appPause();",null);
        web.onPause();
        super.onPause();
    }
    @Override protected void onResume() { super.onResume(); if(web!=null) web.onResume(); }
    @Override public void onBackPressed() {
        new android.app.AlertDialog.Builder(this).setTitle("暂停或退出")
            .setMessage("牌局会自动保存，下次继续原来的手牌。")
            .setPositiveButton("退出",(d,w)->finish())
            .setNeutralButton("暂停",(d,w)->web.evaluateJavascript("window.appBack&&window.appBack();",null))
            .setNegativeButton("继续游戏",null).show();
    }
}
